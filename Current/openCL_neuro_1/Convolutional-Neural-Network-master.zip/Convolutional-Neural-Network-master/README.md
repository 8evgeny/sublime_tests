# Convolutional-Neural-Network
Development of computer vision framework based on deep learning and  GPU programming. We designed a convolutional and a fully connected neural network for object recognition in images. The training of the network and the computation of its output run on GPU, programmed with OpenCL and C++. The algorithm developed during a master thesis.

For more details check my blog posts:

https://sergioskar.github.io/Neural_Network_from_scratch/

https://sergioskar.github.io/Neural_Network_from_scratch_part2/
