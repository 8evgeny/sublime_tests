#ifndef TEMPERATURE_MONITOR_HPP
#define TEMPERATURE_MONITOR_HPP

namespace  temperature
{
double cpu();
double gpu();
}

#endif // TEMPERATURE_MONITOR_HPP
