#ifndef ETH_LOG_TOOLS_HPP
#define ETH_LOG_TOOLS_HPP

#include <string>

std::string sockinfo_to_str(const std::string &ip, int port);

#endif /* ETH_LOG_TOOLS_HPP */
