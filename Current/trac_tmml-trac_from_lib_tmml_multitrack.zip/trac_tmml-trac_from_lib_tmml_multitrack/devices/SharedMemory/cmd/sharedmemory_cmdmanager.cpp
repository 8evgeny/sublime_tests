#include "sharedmemory_cmdmanager.hpp"

SharedMemory_CmdManager::SharedMemory_CmdManager()
{

}
