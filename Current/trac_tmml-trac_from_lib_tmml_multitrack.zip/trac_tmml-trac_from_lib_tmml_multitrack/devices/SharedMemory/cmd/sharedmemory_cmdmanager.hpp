#ifndef SHAREDMEMORY_CMDMANAGER_HPP
#define SHAREDMEMORY_CMDMANAGER_HPP

#include "cmd/cmdmanager.h"

class SharedMemory_CmdManager : public CmdManager
{
public:
    SharedMemory_CmdManager();
};

#endif // SHAREDMEMORY_CMDMANAGER_HPP
