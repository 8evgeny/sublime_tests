#include "sharedmemoryclient.hpp"



bool SharedMemoryClient::send(const std::vector<uint8_t> &cmd)
{
//    return UDPClient::send(cmd.data(), int(cmd.size()));
}
