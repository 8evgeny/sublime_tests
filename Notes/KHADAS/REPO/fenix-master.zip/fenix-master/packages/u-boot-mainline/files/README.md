# FILES

+ [](README.LOGO.md)	logo README
+ splash.bmp.gz		gzipped bmp logo
+ u-boot.logo.tpl	logo dtb injector
