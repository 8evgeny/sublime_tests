#ifndef _rk_graphics_version_h_
#define _rk_graphics_version_h_

#define RK_GRAPHICS_VER "version:+2017-09-28 10:12:42"

#endif // VERSION_H
