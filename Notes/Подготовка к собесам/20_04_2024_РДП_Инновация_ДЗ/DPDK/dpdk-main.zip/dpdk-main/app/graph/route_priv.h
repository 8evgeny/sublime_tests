/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2023 Marvell.
 */

#ifndef APP_GRAPH_ROUTE_PRIV_H
#define APP_GRAPH_ROUTE_PRIV_H

#define MAX_ROUTE_ENTRIES 32

#endif
