# gstreamer-udp
Simple GStreamer UDP Record Sample

---

## ビルド

```bash
docker build -t recorder .
```

---

## 実行

```bash
docker run --rm recorder
```
